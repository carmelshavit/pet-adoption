export const ImagesSrc = {
  dog: "./DogPortrait.jpg",
  sheltersRescues: "./OrganizationOutline.jpg",
  otherAnimal: "./otherAnimal.png",
  cat: "./Cat.jpg",
};
