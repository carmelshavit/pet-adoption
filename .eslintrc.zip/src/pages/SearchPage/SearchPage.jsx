import React, { useContext, useEffect, useState } from "react";
import { ImagesSrc } from "../../../public/ImageSrc";
import {
  CardGroup,
  Card,
  CardContent,
  CardDescription,
  Container,
  Form,
} from "semantic-ui-react";
import { petService } from "../../service/pet.service";
import PetList from "../../cmps/PetList";
import SearchForm from "../../cmps/SearchForm";
import EditAddPet from "../AdminPage/EditAddPet";
import LoginContext from "../../context/LoginContext";
import LikedContext from "../../context/LikedContext";

const SearchPage = () => {
  const [pets, setPets] = useState([]);
  const [selectedPet, setSelectedPet] = useState(null);
  const [isShowEditModal, setIsShowEditModal] = useState(false);
  const [isShowAddModal, setIsShowAddModal] = useState(false);
  const { loggedInUser, setLoggedInUser } = useContext(LoginContext);
  const [isLike, setIsLike] = useState(false);
  const { likedPet, setLikedPet } = useContext(LikedContext);
  const [likedPetsId, setLikedPetsId] = useState({
    petId: "",
    userId: [1, 2, 3, 4],
  });

  const [filterBy, setFilterBy] = useState({
    type: "",
    minHeight: null,
    maxHeight: null,
    minWeight: null,
    maxWeight: null,
    color: "",
    hypoallergenic: false,
    dietary_restrictions: "",
    breed: "",
    name: "",
  });
  const [isPets, setIsPets] = useState(false);

  useEffect(() => {
    searchPet(filterBy);
  }, [filterBy]);

  const updateFilter = (name, value) => {
    console.log(name, value);
    setFilterBy((prevFilter) => ({
      ...prevFilter,
      [name]: value,
    }));
    setIsPets(true);
  };

  const searchPet = async (filterBy) => {
    try {
      const petBySearch = await petService.getPetsBySearch(filterBy);
      console.log("petBySearch", petBySearch);
      setPets(petBySearch);
      // setIsPets(true);
    } catch (error) {
      console.error(error);
    }
  };
  // const toggleLike = async (petId, userId) => {
  //   let clonedPets = JSON.parse(JSON.stringify(pets));
  //   const petIdx = clonedPets.findIndex((pet) => pet.id === petId);
  //   if (petIdx !== -1) {
  //     const pet = clonedPets[petIdx];
  //     if (!pet.likeUsersId) {
  //       pet.likeUsersId = []; // Initialize likeUsersId array if not present
  //     }
  //     const userLikedIdx = pet.likeUsersId.indexOf(userId);
  //     if (userLikedIdx === -1) {
  //       pet.likeUsersId.push(userId); // Add user id to liked users
  //     } else {
  //       pet.likeUsersId.splice(userLikedIdx, 1); // Remove user id from liked users
  //     }
  //     setPets(clonedPets);
  //     setLikedPetsId(clonedPets);
  //     try {
  //       await petService.updatePet(pet);
  //     } catch (error) {
  //       console.log(error);
  //       throw error;
  //     }
  //   } else {
  //     console.log("Pet not found");
  //   }
  // };

  // const showMenu = () => {
  //   setPets([]);
  //   setIsPets(false);
  // };
  const counterLikes = (petId) => {
    setIsLike(true);
    console.log(petId);
  };
  //   const toggleLike = async (petId) => {
  //     let clonedPets = JSON.parse(JSON.stringify(pets))
  //     const petIdx = clonedPets.findIndex(pet => pet.id === petId)
  //     const Pet = clonedPets[petIdx]
  //     const userLikedIdx = Pet.indexOf(loggedInUser.id)

  //     userLikedIdx === -1 ? Pet.push(loggedInUser.id) : Pet.likeUsersId.splice(userLikedIdx, 1)
  //     setPets(clonedPets)
  //     setLikedPet(clonedPets)
  //     console.log(likedPet);

  //     try {
  //         await petService.updatePet(Pet)
  //     } catch (error) {
  //         console.log(error);
  //         throw error
  //     }
  // }
  // const toggleLike = (petId) => {
  //   setLoggedInUser((prevUser) => {
  //     if (prevUser.likedPetsId.includes(petId)) {
  //       return {
  //         ...prevUser,
  //         likedPets: prevUser.likedPetsId.filter((id) => id !== petId),
  //       };
  //     } else {
  //       return {
  //         ...prevUser,
  //         likedPets: [...prevUser.likedPetsId, petId],
  //       };
  //     }
  //   });
  // };
  const openEditModal = (petId) => {
    const pet = pets.find((pet) => pet.id === petId);
    console.log("openEditModal", pet);
    setSelectedPet(pet);
    setIsShowEditModal(true);
  };

  const openAddModal = () => {
    setIsShowAddModal(true);
  };

  const isAdmin = loggedInUser?.is_admin == true;
  //replace card component. add array to render the cards.
  // Todo- cards need to change the state filterBy.type
  //Todo- add a useEffect with dependecy array inside filterBy object
  // const handleCardClick = (filterName, filterValue) => {
  //   updateFilter(filterName, filterValue);
  //   searchPet(filterBy); // Trigger a search when a card is clicked
  // };
  return (
    <Container>
      {!isPets && (
        <div>
          <CardGroup itemsPerRow={4}>
            <Card
              style={{ marginTop: 40 }}
              onClick={() => updateFilter("type", "dog")}
            >
              <img
                src={ImagesSrc.dog}
                alt="Dog"
                style={{ height: "200px", objectFit: "cover" }}
              />
              <CardContent>
                <CardDescription>Dogs</CardDescription>
              </CardContent>
            </Card>
            <Card
              style={{ marginTop: 40 }}
              onClick={() => updateFilter("type", "sheltersRescues")}
            >
              <img
                src={ImagesSrc.sheltersRescues}
                alt="Shelters & Rescues"
                style={{ height: "200px", objectFit: "cover" }}
              />
              <CardContent>
                <CardDescription>Shelters & Rescues</CardDescription>
              </CardContent>
            </Card>
            <Card
              style={{ marginTop: 40 }}
              onClick={() => updateFilter("type", "Cat")}
            >
              <img
                src={ImagesSrc.cat}
                alt="Cat"
                style={{ height: "200px", objectFit: "cover" }}
              />
              <CardContent>
                <CardDescription>Cat</CardDescription>
              </CardContent>
            </Card>
            <Card
              style={{ marginTop: 40 }}
              onClick={() => updateFilter("type", "otherAnimal")}
            >
              <img
                src={ImagesSrc.otherAnimal}
                alt="otherAnimal"
                style={{ height: "200px", objectFit: "cover" }}
              />
              <CardContent>
                <CardDescription>Other Animal</CardDescription>
              </CardContent>
            </Card>
          </CardGroup>
        </div>
      )}
      {/* <Button onClick={showMenu}>back to menu</Button> */}
      {isPets && (
        <>
          <SearchForm filterBy={filterBy} updateFilter={updateFilter} />
          <button onClick={() => searchPet(filterBy)}>Search</button>

          {isAdmin && <button onClick={openAddModal}>Add</button>}
          {/* {isAdmin?  <PetList openEditModal={openEditModal} pets={pets} /> : <PetList pets={pets} />} */}
          <PetList
            openEditModal={openEditModal}
            pets={pets}
            // toggleLike={toggleLike}
          />
        </>
      )}
      <EditAddPet
        isOpenEditModal={isShowAddModal}
        setIsOpenEditModal={setIsShowAddModal}
      />
      <EditAddPet
        isOpenEditModal={isShowEditModal}
        selectedPet={selectedPet}
        setIsOpenEditModal={setIsShowEditModal}
      />
    </Container>
  );
};

export default SearchPage;
