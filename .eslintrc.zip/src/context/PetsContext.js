import React from "react";

const PetsContext = React.createContext();

export default PetsContext