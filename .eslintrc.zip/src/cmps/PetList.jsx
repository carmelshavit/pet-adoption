import React, { useContext } from "react";
import PetPreview from "./PetPreview";
import { useNavigate } from "react-router-dom";
import LoginContext from "../context/LoginContext";

export default function PetList({ pets, openEditModal }) {
  console.log(pets);
  const navigate = useNavigate();
  const { loggedInUser, setLoggedInUser } = useContext(LoginContext);

  const isAdmin = loggedInUser?.is_admin == true;

  return (
    <div>
      <ul className="pet-list">
        {pets.map((pet, index) => (
          <li key={index} onClick={() => navigate(`/pet/${pet.id}`)}>
            {/* Making the list item clickable */}
            <PetPreview pet={pet} key={pet.id} />
            {isAdmin && (
              <button onClick={() => openEditModal(pet.id)}>Edit</button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
